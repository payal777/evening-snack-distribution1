<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class user_model extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }

	function get_user($email, $pwd)
	{
		$this->db->where('email', $email);
		$this->db->where('password', md5($pwd));
        $query = $this->db->get('user');
		return $query->result();
	}

	// get user
	function get_user_by_id($id)
	{
		$this->db->where('id', $id);
        $query = $this->db->get('user');
		return $query->result();
	}

	// insert
	function insert_user($data)
    {
		return $this->db->insert('user', $data);
	}
	
	  public function likevote_add($data)
    {
		$this->db->where('usr_id', $data[usr_id]);
        $query = $this->db->get('vote');
		
if($update_query > 0){

 $this->db->where('usr_id',$data->usr_id);
      $this->db->update('vote',$data);
}
else{
  $this->db->insert('vote', $data);
        return $this->db->insert_id();
    }
	}
	
		  public function dislikevote_add($da)
    {
		//extract($da);
		$this->db->where('usr_id', $da[usr_id]);
        $query = $this->db->get('vote');
		
if($query->num_rows()>0){

 $this->db->where('usr_id',$da[usr_id]);
      $this->db->update('vote',$da);
}
else{
  $this->db->insert('vote', $da);
        return $this->db->insert_id();
    }
    }

	public function get_data(){
        $query=$this->db->query("SELECT *
                                 FROM vote");
        return $query->result_array();
    }

		public function update_vote_by_id($id){
			$update = mysql_query("update vote set total_votes=total_votes+1,likes=likes+1");
		  $select = mysql_query("SELECT * FROM vote");
		  while($row=mysql_fetch_array($select))
		  {
			$total_votes=$row['total_votes'];
			$likes=$row['likes'];
			$dislike=$row['dislike'];

		    echo "<p id='total_rating'>Total Ratings ( ".$total_votes." )</p>";
		    // echo "<p id='total_like'><img src='like.png'>".$likes."</p><div id='like_bar'></div>";
		    // echo "<p id='total_dislike'><img src='dislike.png'>".$dislike."</p><div id='dislike_bar'></div>";
		    exit();
		  }
		}

		public function update_disvote_by_id($id){
			$update = mysql_query("update vote set total_votes=total_votes,dislike=dislike-1");
		  $select = mysql_query("SELECT * FROM vote");
		  while($row=mysql_fetch_array($select))
		  {
		  	$total_votes=$row['total_votes'];
			  $likes=$row['likes'];
			  $dislike=$row['dislike'];

		    echo "<p id='total_rating'>Total Ratings ( ".$total_votes." )</p>";
		    // echo "<p id='total_like'><img src='like.png'>".$likes."</p><div id='like_bar'></div>";
		    // echo "<p id='total_dislike'><img src='dislike.png'>".$dislike."</p><div id='dislike_bar'></div>";
		    exit();
		  }
		}

		public function get_by_idlike($id){
			$this->db->update('vote', $data, $where);
	return $this->db->affected_rows();
		}

		public function get_by_id_dislike($id){
			$this->db->update('vote', $data, $where);
	return $this->db->affected_rows();
		}



}?>
