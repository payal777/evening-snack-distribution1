<?php

class Test extends CI_Controller{

	public function index(){
	echo "This is index function.";
	}
	
	public function ex1(){
	echo "Welcome to code igniter.";
	}
}
?>