<?php
class store_rating extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url','html'));
        $this->load->library('session');
        $this->load->database();
        $this->load->model('user_model');
    }

    function index()
    {
        $details = $this->user_model->update_vote_by_id($this->session->userdata('uid'));
        $data['uname'] = $details[0]->fname . " " . $details[0]->lname;
        $data['uemail'] = $details[0]->email;
        $this->load->view('profile_view', $data);
    }

    function dislike(){
      $details = $this->user_model->update_disvote_by_id($this->session->userdata('uid'));
      $data['uname'] = $details[0]->fname . " " . $details[0]->lname;
      $data['uemail'] = $details[0]->email;
      $this->load->view('profile_view', $data);
    }

    public function ajax_editlike($id)
{
  $data = $this->user_model->get_by_idlike($id);
  echo json_encode($data);
}

public function ajax_editdislike($id)
{
$data = $this->user_model->get_by_id_dislike($id);
echo json_encode($data);
}


}
?>
