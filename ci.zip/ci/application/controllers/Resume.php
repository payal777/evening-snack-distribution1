<?php
class Resume extends CI_Controller{
public function index(){
        $this->load->view('resume');   
}
}
?>