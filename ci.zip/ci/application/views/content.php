<html>
	<head>
		<title>content</title>
	</head>
	<body>



<div id="content">  
        <h1>Welcome to CodeIgniter</h1>  
        <p>CodeIgniter is a powerful PHP framework with a very small footprint, built for developers who need a simple and elegant toolkit to create full-featured web applications. CodeIgniter was created by EllisLab, and is now a project of the British Columbia Institute of Technology.</p> 
	<p>It is an application development framework, which can be used to develop websites, using PHP. It is an Open Source framework. It has a very rich set of functionality, which will increase the speed of website development work.</p>
	<p>Features of CodeIgniter are listed below </p>
	<p>Model-View-Controller Based System</p>
	<p>Extremely Light Weight</p>
	<p>Query Builder Database Support</p>
	<p>Form and Data Validation</p>
	
</div> 
	</body>
</html>