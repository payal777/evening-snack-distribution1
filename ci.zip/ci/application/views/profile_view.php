<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>My Profile | Evening Snacks</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home">EVENING SNACKS</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
				<?php echo $_SESSION['uid']; ?>
				
				
				<li><a href="<?php echo base_url(); ?>index.php/book">Users</a></li>
				<li><a href="<?php echo base_url(); ?>index.php/home/logout">Log Out</a></li>
			</ul>
		</div>
	</div>
</nav>
<div class="container">
	<div class="row">
		<div class="col-md-4">
			<h5>Profile Summary</h5>
			<hr/>
			<p>Name: <?php echo $uname; ?> </p>
			<p>Email: <?php echo $uemail; ?></p>
		</div>
		<div class="col-md-8">
			<p>If you want to order evening snacks, click on thumbs Up</p>
		</div>
	</div>
	<div class="row">
  <div class="col-sm-4">
   <p style="font-size:200px;">5<p>
	</div>
  <!-- <div class="col-sm-4" style="border-right:1px solid #cecece;"> -->
		<div class="col-sm-4">
		<!-- <p><button type="button">Approve</button></p> -->
	 <p style="padding-top: 15px;margin-left:50px;"><span style="font-size:50px;" class="glyphicon glyphicon-cutlery"></span></p>
   <p><span style="font-size:100px;" class="glyphicon glyphicon-arrow-left"></span></p>
	 		<!-- <p><button type="button">Cancel</button></p> -->
	</div>
  <div class="col-sm-4">
  <button class="btn btn-warning" onclick="save_like(<?php echo $_SESSION['uid']; ?>)"><span style="font-size:200px;"><i class="glyphicon glyphicon-thumbs-up"></i></span></button>
  <button class="btn btn-warning" style="vertical-align:bottom;background-color:#d62b05;border-color:#d62b05;" onclick="save_dislike(<?php echo $_SESSION['uid']; ?>)"><span style="font-size:50px;"><i class="glyphicon glyphicon-thumbs-down"></i></span></button>
	</div>
</div>
<br>
<div style="border:1px solid #cecece;">
	<span class="glyphicon glyphicon-thumbs-up"></span>
	<span>Payal</span>
	<span>5 sec</span>
</div>
<br>
<div style="border:1px solid #cecece;">
	<span class="glyphicon glyphicon-thumbs-up"></span>
	<span>Kiran</span>
	<span>1 min</span>
</div>
<br>
<div style="border:1px solid #cecece;">
	<span class="glyphicon glyphicon-thumbs-up"></span>
	<span>Sahil</span>
	<span>2 min</span>
</div>
    <!-- <script type="text/javascript">
    var clicks = 0;
		var unclicks= clicks;
    function onClick() {
        clicks += 1;
        document.getElementById("clicks").innerHTML = clicks;
    };
		function onUnclick() {
				unclicks = clicks-1;
				document.getElementById("unclicks").innerHTML = unclicks;
		};
    </script>
		<button type="button" class="btn btn-default btn-sm" onClick="onClick()">
	<span class="glyphicon glyphicon-thumbs-up"></span> Like
</button>
    <p>Clicks: <a id="clicks">0</a></p>
		<button type="button" class="btn btn-default btn-sm" onClick="onUnclick()">
	<span class="glyphicon glyphicon-thumbs-down"></span> Unlike
</button>
		<p>UnClicks: <a id="unclicks"></a></p> -->



		<script type="text/javascript">

		function save_like(id)
    {
      var url;
          url = "<?php echo ('http://localhost/ci/index.php/profile/save_like')?>/" + id;
       // ajax adding data to database
          $.ajax({
            url : url,
            type: "GET",
            //data: "",
            //dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               //$('#modal_form').modal('hide');
              //location.reload();// for reload a page
				alert("success");
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
    }

function save_dislike(id)
    {
      var url;
          url = "<?php echo ('http://localhost/ci/index.php/profile/save_dislike')?>/" + id;
       // ajax adding data to database
          $.ajax({
            url : url,
            type: "GET",
            //data: $('#form').serialize(),
            //dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               //$('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
    }
</script>



<!-- <button class="btn btn-warning" onclick="save_like()"><i class="glyphicon glyphicon-thumbs-up"></i></button>
<button class="btn btn-warning" onclick="save_dislike()"><i class="glyphicon glyphicon-thumbs-down"></i></button> -->
  <div id="totalvotes"></div>
</div>
<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
</body>
</html>
